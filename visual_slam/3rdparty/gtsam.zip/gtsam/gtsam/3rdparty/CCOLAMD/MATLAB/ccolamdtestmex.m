function [P, stats] = ccolamdtestmex (A, knobs)				    %#ok
% CCOLAMDTESTMEX test function for ccolamd
% Example:
%   [ P, stats ] = ccolamdtest (A, knobs) ;
% See also ccolamd

% Copyright 1998-2007, Timothy A. Davis, Stefan Larimore, and Siva Rajamanickam
% Developed in collaboration with J. Gilbert and E. Ng.

error ('ccolamdtestmex mexFunction not found') ;
