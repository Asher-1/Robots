java -jar ~/src/statsvn-0.7.0/statsvn.jar -output-dir stats -exclude "examples/Data/**/*;gtsam/3rdparty/**/*" logfile.log .
