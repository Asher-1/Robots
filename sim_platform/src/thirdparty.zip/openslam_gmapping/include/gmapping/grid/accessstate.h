#ifndef ACCESSTATE_H
#define ACCESSTATE_H

namespace GMapping {
enum AccessibilityState{Outside=0x0, Inside=0x1, Allocated=0x2};
};

#endif

