# 脚本说明

此脚本用于从源码安装cartographer并跑课程仿真机器人xbot。

### 操作说明

```
chmod +x Xbot_cartogarpher.sh 
./Xbot_cartogarpher.sh 
```

