## Ubuntu 18.04 课程代码仓库升级CONTRIBUTORS 

### 安传旭

- 电信科学技术研究院
- email: anchuanxu@126.com
- github: [https://github.com/anchuanxu](https://github.com/anchuanxu)

### 彭晓星

- 北京理工大学
- email: 1119832974@qq.com
- github: [https://github.com/pengxiaoxing0906](https://github.com/pengxiaoxing0906)

### 蓝煜东

- 北京航空航天大学
- email: lan1106628183@163.com
- github: [https://github.com/staillyd](https://github.com/staillyd)

### 陈家友

- 电信科学技术研究院
- email: 1132021192@qq.com
- github: [https://github.com/chenjy9581](https://github.com/chenjy9581)

##### Update :2019/7

##### copyright

![Logo](./joint_logo.png)
