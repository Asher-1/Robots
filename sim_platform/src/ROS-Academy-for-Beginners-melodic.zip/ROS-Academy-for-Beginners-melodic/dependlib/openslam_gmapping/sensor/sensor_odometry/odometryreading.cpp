#include "gmapping/sensor/sensor_odometry/odometryreading.h"

namespace GMapping{

OdometryReading::OdometryReading(const OdometrySensor* odo, double time):
	SensorReading(odo,time){}

};

