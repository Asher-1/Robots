# rtabmap 在仿真环境下的运行

### 操作步骤
1. 根据自己的ROS版本,安装对应的rtabmap-ros
2. 从源构建,添加依赖(包括可选的OpenCV,g2o,GTSAM,Freenect2)
3. 安装RTAM-Map(注意不要直接克隆在catkin 工作空间下)
4. 更新版本
5. 输入指令,运行环境,开始建图.

##### 详细操作请参考:rtabmap 在仿真环境下的运行操作指南